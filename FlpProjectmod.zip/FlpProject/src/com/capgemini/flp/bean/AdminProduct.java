package com.capgemini.flp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="admin_product")
public class AdminProduct {

@Id
@Column(name="product_Id")
private int productId;
@Column(name="product_Name")
private String productName;
@Column(name="product_category")
private String productCategory;
@Column(name="product_Description")
private String productDescription;
@Column(name="product_Price")
private double productPrice;
@Column(name="product_Image")
private String productImage;
@Column(name="product_Quantity")
private int productQuantity;
@Column(name="seller_email_Id")
private String sellerEmail;
@Column(name="product_Discount")
private String productDiscount;
@Column(name="timeForDiscount")
private int timeDiscount;
@Column(name="product_promo")
private String productPromo;
@Column(name="timeForPromo")
private int timePromo;
@Column(name="numberOfProductSold")
private int productSold;
@Column(name="numberOfProductExchanged")
private int productExchange;
@Column(name="sellingAmount")
private double sellingAmount;
@Column(name="exchangeAmount")
private double exchangeAmount;

public int getProductId() {
	return productId;
}
public void setProductId(int productId) {
	this.productId = productId;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public String getProductCategory() {
	return productCategory;
}
public void setProductCategory(String productCategory) {
	this.productCategory = productCategory;
}
public String getProductDescription() {
	return productDescription;
}
public void setProductDescription(String productDescription) {
	this.productDescription = productDescription;
}
public double getProductPrice() {
	return productPrice;
}
public void setProductPrice(double productPrice) {
	this.productPrice = productPrice;
}
public String getProductImage() {
	return productImage;
}
public void setProductImage(String productImage) {
	this.productImage = productImage;
}
public int getProductQuantity() {
	return productQuantity;
}
public void setProductQuantity(int productQuantity) {
	this.productQuantity = productQuantity;
}
public String getSellerEmail() {
	return sellerEmail;
}
public void setSellerEmail(String sellerEmail) {
	this.sellerEmail = sellerEmail;
}
public String getProductDiscount() {
	return productDiscount;
}
public void setProductDiscount(String productDiscount) {
	this.productDiscount = productDiscount;
}
public int getTimeDiscount() {
	return timeDiscount;
}
public void setTimeDiscount(int timeDiscount) {
	this.timeDiscount = timeDiscount;
}
public String getProductPromo() {
	return productPromo;
}
public void setProductPromo(String productPromo) {
	this.productPromo = productPromo;
}
public int getTimePromo() {
	return timePromo;
}
public void setTimePromo(int timePromo) {
	this.timePromo = timePromo;
}
public int getProductSold() {
	return productSold;
}
public void setProductSold(int productSold) {
	this.productSold = productSold;
}
public int getProductExchange() {
	return productExchange;
}
public void setProductExchange(int productExchange) {
	this.productExchange = productExchange;
}
public double getSellingAmount() {
	return sellingAmount;
}
public void setSellingAmount(double sellingAmount) {
	this.sellingAmount = sellingAmount;
}
public double getExchangeAmount() {
	return exchangeAmount;
}
public void setExchangeAmount(double exchangeAmount) {
	this.exchangeAmount = exchangeAmount;
}


}
