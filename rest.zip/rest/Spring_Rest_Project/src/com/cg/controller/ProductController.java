package com.cg.controller;

import java.util.List;

import javax.ws.rs.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Product;
import com.cg.service.IProductService;

@CrossOrigin(origins = "*")
@RestController
public class ProductController {

	@Autowired
	IProductService productService;

	@RequestMapping(value = "/create", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
	public Product addproduct(@RequestBody Product product) {

		//Product product = new Product(id, name, price);
		productService.addProduct(product);

		return product;
	}
	
	
	/*@RequestMapping(value = "/create/{id}/{name}/{price}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET,headers = "Accept=application/json")
	public Product addproduct(@PathVariable("id") Integer id,@PathVariable("name") String name,@PathVariable("price") Double price) {

		Product product = new Product(id, name, price);
		productService.addProduct(product);

		return product;
	}*/

	@RequestMapping(value = "/products", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<Product> getAllProducts(Model model) {
		return productService.getAllProducts();
	}

}
