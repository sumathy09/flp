package com.cg.staticDb;

import java.util.ArrayList;
import java.util.List;

import com.cg.model.Product;

public class ProductDB {

	private static List<Product> products = new ArrayList<>();

	static {
		products.add(new Product(101, "Laptop", 45678.32));
		products.add(new Product(102, "IPad", 65656.62));
		products.add(new Product(103, "Iphone", 54678.3232));
		products.add(new Product(104, "Ipod", 23123.312));
		products.add(new Product(105, "TV", 54123.678));
	}

	public static List<Product> getProducts() {
		return products;
	}

	public static void setProducts(List<Product> products) {
		ProductDB.products = products;
	}

}
