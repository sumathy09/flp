package com.cg.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.model.Product;
import com.cg.staticDb.ProductDB;

@Repository
public class ProductDAoImpl implements IProductDAO {

	@Override
	public List<Product> getAllProducts() {
		return ProductDB.getProducts();
	}

	@Override
	public void addProduct(Product product) {
		boolean result = ProductDB.getProducts().add(product);
		System.out.println("1111 " + result);
		if (result) {
			System.out.println(product);
		}
	}
}
