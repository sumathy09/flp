package com.capgemini.flp.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.flp.bean.Delivery;
import com.capgemini.flp.exception.CustomerException;

public interface IDAODelivery {
	ArrayList<Delivery> getStatus() throws CustomerException ;
}
