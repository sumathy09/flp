package com.capgemini.flp.dao;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.bean.Delivery;
import com.capgemini.flp.exception.CustomerException;
 
 @Repository
public class DAODeliveryImpl implements IDAODelivery {
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public ArrayList<Delivery> getStatus() throws CustomerException {
		// TODO Auto-generated method stub
		ArrayList<Delivery> list = new ArrayList<>();
		String jpql = "Select delivery from Delivery delivery ";
		TypedQuery<Delivery> query = entityManager.createQuery(jpql,Delivery.class);
		list = (ArrayList<Delivery>) query.getResultList();
		return list;
	
	
	
	 

	}}
