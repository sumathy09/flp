package com.capgemini.flp.dao;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.bean.CustomerLogin;
import com.capgemini.flp.bean.Delivery;
 
import com.capgemini.flp.bean.Payment;
import com.capgemini.flp.exception.CustomerException;
 



 @Repository
public class DAODeliveryImpl implements IDAODelivery {
	 CustomerLogin customer=new CustomerLogin();
	 Payment pay=new Payment();
	 
	@PersistenceContext
	EntityManager entityManager;



	@Override
	public Delivery add(Integer transactionId,Delivery delivery) {
		// TODO Auto-generated method stub
		//delivery.setDeliveryId(1);
	  		delivery.setCustomerEmail(customer.getEmailId());
		delivery.setName(customer.getName());
		delivery.setAddress(customer.getAddress());
		delivery.setPhoneNumber(customer.getPhoneNumber());
		delivery.setProductId(pay.getProductId());
		delivery.setProductName(pay.getProductName());
		delivery.setTransactionId(pay.getTransactionId());
		LocalDate orderDate=LocalDate.now();
		delivery.setOrderDate(orderDate);
		delivery.setReachDate("Your products will be delivered within 5 days");
		entityManager.persist(delivery);
		return delivery;
	}
	@Override
	public Delivery getStatus(Integer transactionId) throws CustomerException {
		// Delivery delivery=entityManager.find(Delivery.class,productId);
		 TypedQuery<Delivery> query= entityManager.createQuery("Select customerDetails from Delivery customerDetails where CustomerDetails.transactionId=?1",Delivery.class);
			query.setParameter(1, transactionId);	 
		Delivery customer=query.getSingleResult();
		return customer;
	}
 
	 

	}
