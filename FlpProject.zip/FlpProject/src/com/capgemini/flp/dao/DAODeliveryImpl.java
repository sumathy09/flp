package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.bean.CustomerLogin;
import com.capgemini.flp.bean.Delivery;
import com.capgemini.flp.bean.Order;
import com.capgemini.flp.bean.Payment;
import com.capgemini.flp.exception.CustomerException;
 



 @Repository
public class DAODeliveryImpl implements IDAODelivery {
	 CustomerLogin customer=new CustomerLogin();
	 Payment pay=new Payment();
	 Order order=new Order();
	@PersistenceContext
	EntityManager entityManager;



	@Override
	public Delivery add(Integer productId,Delivery delivery) {
		// TODO Auto-generated method stub
	 
		delivery.setCustomerEmail(customer.getEmailId());
		delivery.setName(customer.getName());
		delivery.setAddress(customer.getAddress());
		delivery.setPhoneNumber(customer.getPhoneNumber());
		delivery.setProductId(pay.getProductId());
		delivery.setProductName(pay.getProductName());
		delivery.setOrderDate(order.getOrderDate());
		delivery.getReachDate();
		entityManager.persist(delivery);
		return delivery;
	}
	@Override
	public Delivery getStatus(Integer productId) throws CustomerException {
		// Delivery delivery=entityManager.find(Delivery.class,productId);
		 TypedQuery<Delivery> query= entityManager.createQuery("Select customerDetails from Delivery customerDetails where CustomerDetails.productId=?1",Delivery.class);
			query.setParameter(1, productId);	 
		Delivery customer=query.getSingleResult();
		return customer;
	}
 
	 

	}
