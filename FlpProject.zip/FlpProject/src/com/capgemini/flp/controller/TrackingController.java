package com.capgemini.flp.controller;
 import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.bean.Delivery;
import com.capgemini.flp.exception.CustomerException;
import com.capgemini.flp.service.IServiceDelivery;
 
 

@Controller
 
public class TrackingController {	
	
	@Autowired
	IServiceDelivery service;
	 
@RequestMapping(value="/enter",method=RequestMethod.GET)	
public ModelAndView add(){
	Delivery d=new Delivery();
	return new ModelAndView("disp","cust",d);
	
}

@RequestMapping(value="get",method=RequestMethod.POST)
public ModelAndView get(@RequestParam Integer productId,Delivery delivery)throws CustomerException{
	Delivery add=service.add(productId,delivery);
	return new ModelAndView("add","c",add);
	
}

@RequestMapping(value="/home",method=RequestMethod.GET)

public ModelAndView accountId() {
	 Delivery d=new Delivery();
	return new ModelAndView("home","customer",d);
}

   @RequestMapping(value="return",method=RequestMethod.POST)
	public ModelAndView getdetails(@RequestParam Integer productId) throws CustomerException{
		Delivery status=service.getStatus(productId);
		 
		return new ModelAndView("status","customer",status);
		
	}
	
	
	 
}
