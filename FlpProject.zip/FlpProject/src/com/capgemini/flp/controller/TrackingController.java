package com.capgemini.flp.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.bean.Delivery;

@Controller
@RequestMapping(value="/status")

public class TrackingController {
	 
		
		
		@RequestMapping(method=RequestMethod.GET)
		public ModelAndView tracking() {
			return new ModelAndView("tracking","tracking",new Delivery());
		}
		
		@RequestMapping(value="/verify", method=RequestMethod.POST)
		public String doTracking( @Valid @ModelAttribute("delivery") Delivery delivery,
				BindingResult result, HttpServletRequest request, Model model){
			 
			return "trackingDetails";		
			 
		}
}
