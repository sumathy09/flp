package com.capgemini.flp.controller;
 import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.bean.Delivery;
import com.capgemini.flp.exception.CustomerException;
import com.capgemini.flp.service.IServiceDelivery;
 

@Controller
 

public class TrackingController {	
	
	
	@Autowired
	IServiceDelivery service;
	@RequestMapping(value="/status")
	public ModelAndView status( String email)throws CustomerException{
		ArrayList<Delivery> list=service.getStatus();
		return new ModelAndView("status","customer",list);
		
		 
	}
	
	
	 
}
