package com.capgemini.flp.service;

import java.util.ArrayList;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.bean.Delivery;
import com.capgemini.flp.dao.IDAODelivery;
import com.capgemini.flp.exception.CustomerException;

@Service
@Transactional
public class ServiceDeliveryImpl implements IServiceDelivery {

	@Autowired
	IDAODelivery daoDelivery;
	@Override
	public ArrayList<Delivery> getStatus() throws CustomerException {
		// TODO Auto-generated method stub
		return daoDelivery.getStatus();
	}

}
