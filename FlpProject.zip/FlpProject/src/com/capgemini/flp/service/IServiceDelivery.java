package com.capgemini.flp.service;
import com.capgemini.flp.bean.Delivery;
import com.capgemini.flp.exception.CustomerException;
 
 
public interface IServiceDelivery {
 
	Delivery getStatus(Integer productId) throws CustomerException;

	Delivery add(Integer productId,Delivery delivery);
	 
}
