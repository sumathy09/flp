package com.capgemini.flp.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.flp.bean.Delivery;
import com.capgemini.flp.exception.CustomerException;
 
 
public interface IServiceDelivery {
	ArrayList<Delivery> getStatus() throws CustomerException ;
	 
}
