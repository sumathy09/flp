package com.capgemini.flp.service;
import com.capgemini.flp.bean.Delivery;
import com.capgemini.flp.exception.CustomerException;
 
 
public interface IServiceDelivery {
 
	Delivery getStatus(Integer transactionId) throws CustomerException;

	Delivery add(Integer transactionId,Delivery delivery);
	 
}
