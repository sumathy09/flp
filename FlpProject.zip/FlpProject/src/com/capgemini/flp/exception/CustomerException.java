package com.capgemini.flp.exception;

public class CustomerException extends Exception {
	public CustomerException(String msg){
		super(msg);
		}

}
